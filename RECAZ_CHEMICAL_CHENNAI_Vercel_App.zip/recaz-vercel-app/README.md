# RECAZ CHEMICAL CHENNAI — Inventory Management

A static Vercel-ready deployment of the supplied inventory management app.

## Deploy with Vercel

### Option 1: Vercel CLI

1. Install Node.js.
2. In this folder, run `npm install -g vercel`.
3. Run `vercel login` and sign in to your Vercel account.
4. Run `vercel --prod` and follow the prompts.

### Option 2: GitHub + Vercel

1. Upload the contents of this folder to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Select **Other** as the framework preset. No build command is required; use `.` as the output directory if prompted.
4. Deploy.

## Important data note

The supplied app stores inventory, sales, purchases, and backup data in browser `localStorage`. This means data stays in the browser/device where it is entered. It is not a shared cloud database and will not automatically synchronize across devices or users. Use the app's Excel export and JSON backup/restore features regularly. Clearing browser site data can remove locally stored records.

Excel export loads ExcelJS from jsDelivr, so an internet connection is required for Excel export.
